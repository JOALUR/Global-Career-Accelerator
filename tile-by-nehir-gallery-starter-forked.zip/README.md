## Asks

_Please see my wireframe (in assets) for reference._

- "On very small devices like phones, I'd like the tiles to display as one column."
- "On small or medium devices like tablets, I'd like the tiles to display as two columns."
- "On very large devices, like laptops and desktops, I'd like the tiles to display as four columns."
- "Will you please make sure the spacing on the page and between the tiles looks right?"

## LevelUp
- "Can you add my brand name 'Tile by Nehir' to the top of the page? Large and centered. I use 'Playfair Display' as the font for my brand."
- "Since my brand is international can you add a google translate button on the page? I found [this article](https://www.geeksforgeeks.org/add-google-translate-button-webpage/) that I think will help."
