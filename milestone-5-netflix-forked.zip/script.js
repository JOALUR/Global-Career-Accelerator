/* This is where you'll complete the Milestone. Open your README.md file and click 'Open Preview' for detailed instuctions! */

let dramaShows = [
  "Ginny & Georgia",
  "Outlander",
  "Grey's Anatomy",
  "Ozark",
  "The Queen's Gambit",
];

let fantasyShows = [
  "Supernatural",
  "The Sandman",
  "Wednesday",
  "The Witcher",
  "Avatar: The Last Airbender",
];

let comedyShows = [
  "Arrested Development",
  "Dead to Me",
  "Seinfeld",
  "Emily in Paris",
  "The Good Place",
];

function chooseRandomGenre() {
  //randomly pick between the 3 genres
  //let each genre equal an int 0-2
  //use getRandomNumber(min, max) to randomly select a genre
  const randomGenre = getRandomNumber(0, 2);
  //array of all 3 genres
  const genres = ["drama", "fantasy", "comedy"];
  return genres[randomGenre];
}

function displayRandomShow(genre) {
  // displayShow(show)
  //if statement for selecting random shows in random genre
  if (genre === "random") {
    genre = chooseRandomGenre();
  }

  //variable to randomly get index of shows
  let randomIndex;
  //variable for selecting random shows from array of genre
  let show;

  //if statement for each genre displaying a random show
  if (genre === "drama") {
    //random index
    randomIndex = getRandomNumber(0, dramaShows.length - 1);
    //random show from drama section using randomIndex
    shows = dramaShows[randomIndex];
  } else if (genre === "fantasy") {
    //random index
    randomIndex = getRandomNumber(0, fantasyShows.length - 1);
    //random show from fantasy section using randomIndex
    shows = fantasyShows[randomIndex];
  } else if (genre === "comedy") {
    //random index
    randomIndex = getRandomNumber(0, comedyShows.length - 1);
    //random show from comedy section using randomIndex
    shows = comedyShows[randomIndex];
  }

  //displays selected show
  displayShow(shows);
}

// console.log(getRandomNumber(0, 4));
// console.log(getRandomNumber(0, 4));
// console.log(getRandomNumber(0, 4));
// console.log(getRandomNumber(0, 4));
// console.log(getRandomNumber(0, 4));

// console.log(displayShow("The Witcher"));
// console.log(displayShow("The Queen's Gambit"));

console.log(`
N   N  EEEEE  TTTTT  FFFFF  L      I  X   X
NN  N  E        T    F      L      I   X X 
N N N  EEEE     T    FFF    L      I    X  
N  NN  E        T    F      L      I   X X 
N   N  EEEEE    T    F      LLLLL  I  X   X
`);
