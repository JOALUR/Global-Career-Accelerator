/* This is where you'll complete the Milestone. Open your README.md file and click 'Open Preview' for detailed instuctions! */
// getRoomLength(roomNumber)
// getRoomWidth(roomNumber)
// showResult(result)

const { isVariableDeclaration } = require("typescript");

function calculateCarpet() {
  // 👇 Write your code here 👇
  // console.log(getRoomWidth(1));
  // console.log(getRoomLength(1));
  // console.log(showResult(14));
  // console.log("click");

  // 1. Get width for room one and assign it to variable
  let roomOneWidth = getRoomWidth(1);
  // 2. Get length for room one and assign it variable
  let roomOneLength = getRoomLength(1);
  console.log(roomOneWidth, roomOneLength);
  // 3. Get width for room two and assign it varibale
  let roomTwoWidth = getRoomWidth(2);
  // 4. Get length for room two and assign it variable
  let roomTwoLength = getRoomLength(2);
  console.log(roomTwoWidth, roomTwoLength);
  // 5. Get room one square feet: multiply length * wdith using variales and assign it to another variable
  let roomOneArea = roomOneWidth * roomOneLength;
  // 6. get room two square feet: multiple length and width and assign it a variable
  let roomTwoArea = roomTwoWidth * roomTwoLength;
  console.log(roomOneArea, roomTwoArea);
  // 7. get an extra 10%: add square feet of room one and two then multiply by 10% or 0.1
  let areaTotal = roomOneArea + roomTwoArea;
  const extra = 0.1;
  let areaExtra = areaTotal * extra;
  console.log(areaTotal, extra, areaExtra);
  // 8. Display square feet on page using showResult()
  showResult(150);
  console.log(showResult);
  // let final = showResult(areaExtra);
  // console.log(final);
}
calculateCarpetTest();

/* LEVEL UP! (optional) 
	1. Function explanations: 


	2. Custom styles added: 


*/

/*

The function validateRoomNumber uses if loops to make sure 
the user is inputing rooms 1 or 2 for room number. If user 
inputs a undefined value, string value, or a number value
that is not 1 or 2 they will be prompted with message and
have to try again until they put the correct room numbers

*/

/*

There were also function created for roomLength, roomWidth, 
and showResult. These were functions put in place to properly
get the length, width, and give a result on the page.

*/
